(function($) {

	$( document ).ready(function() {

		$('.somfrp-wp-picker-container .somfrp-colour-picker').wpColorPicker({
			width: 250,
			hide: true
		});

	});

})( jQuery );